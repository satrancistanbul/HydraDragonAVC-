# Resources

This file exists so the src/main/resources directory will exist and keep Eclipse happy
